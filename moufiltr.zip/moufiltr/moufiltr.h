/*++
Copyright (c) 2008  Microsoft Corporation

Module Name:

moufiltr.h

Abstract:

This module contains the common private declarations for the mouse
packet filter

Environment:

kernel mode only

Notes:


Revision History:


--*/

#ifndef MOUFILTER_H
#define MOUFILTER_H

#include <ntddk.h>
#include <kbdmou.h>
#include <ntddmou.h>
#include <ntdd8042.h>
#include <wdf.h>



#if DBG

#define TRAP()                      DbgBreakPoint()

#define DebugPrint(_x_) DbgPrint _x_

#else   // DBG

#define TRAP()

#define DebugPrint(_x_)

#endif

//DATOS PRE-EFINIDOS EN CUANTO A LAS PROPIEDADES DEL PUNTERO:

#define DEFAULT_MAXVEL_X 200		//
#define DEFAULT_MAXVEL_Y 200		//
#define DEFAULT_ACTIVE FALSE		//
#define DEFAULT_LEFTHAND FALSE		//
#define DEFAULT_ACCEL_X 1			//
#define DEFAULT_ACCEL_Y 1			//
#define DEFAULT_FRICC_X 1			//
#define DEFAULT_FRICC_Y 1			//
#define STANDARIZER 30				//
#define DEFAULT_MS 1				//


//VARIABLE TEMPORALES PARA USARLOS EN MEMEORIA:

WDFTIMER hTimer;						// Variable para el control del tiempo en el filtro al momento de ejecutar la ficcion en el cursor.
ULONG active = FALSE;					// Variable para el control de activo/inactivo del filtro. 
ULONG counterForceActive = FALSE;		// Variable para el control de activo/inactivo de la desaceleracion.
LONG deltaPosX = 0;						// variable de la posicion X del cursor.
LONG deltaPosY = 0;						// Variable de la posicion Y del cursor. 
BOOLEAN allowFriction;					// Variable para el control de activo/inactivo de la fuerza de friccion.
MOUSE_INPUT_DATA mouseFricc;			// Variable para el manejo de la friccion en cuanto a los datos de entrada en el filtrado. 
ULONG regActive = TRUE;					// Variable para el control de activo/inactivo del filtro.
ULONG regLeftHanded = TRUE;				// Variable para el control de activo/inactivo de el mouse para surdos.
LONG curVelx = 0;						// variable de la velocidad en el eje X del cursor.
LONG curVely = 0;						// variable de la velocidad en el eje Y del cursor.
BOOLEAN Active = TRUE;



//VARIABLES PARA EL MANEJO DE LOS ATRIBUTOS TOMADOS DEL REGISTRO:

UNICODE_STRING regMaxVelXStr;				//velocidad maxima en el eje X.
UNICODE_STRING regMaxVelYStr;				//velocidad maxima en el eje Y.
UNICODE_STRING regActiveStr;				//filtro activado / desactivado.
UNICODE_STRING regAccelXStr;				//Constante de la acceleracion en el eje X.
UNICODE_STRING regAccelYStr;				//Constante de la acceleracion en el eje Y.
UNICODE_STRING regFriccXStr;				//Friccion en el eje X.
UNICODE_STRING regFriccYStr;				//Friccion en el eje Y.
UNICODE_STRING regMilliSegsAcelStr;			//tiempo en milisegundos de la aceleracion.
UNICODE_STRING regMilliSegsFriccStr;		//tiempo en milisegundos de la aceleracion.	


typedef struct _DEVICE_EXTENSION
{

	//
	// Previous hook routine and context
	//                               
	PVOID UpperContext;

	PI8042_MOUSE_ISR UpperIsrHook;

	//
	// Write to the mouse in the context of MouFilter_IsrHook
	//
	IN PI8042_ISR_WRITE_PORT IsrWritePort;

	//
	// Context for IsrWritePort, QueueMousePacket
	//
	IN PVOID CallContext;

	//
	// Queue the current packet (ie the one passed into MouFilter_IsrHook)
	// to be reported to the class driver
	//
	IN PI8042_QUEUE_PACKET QueueMousePacket;

	//
	// The real connect data that this driver reports to
	//
	CONNECT_DATA UpperConnectData;


} DEVICE_EXTENSION, *PDEVICE_EXTENSION;

WDF_DECLARE_CONTEXT_TYPE_WITH_NAME(DEVICE_EXTENSION,
	FilterGetData)

	//
	// Prototypes
	//
	DRIVER_INITIALIZE DriverEntry;

EVT_WDF_TIMER TimerFricc;

EVT_WDF_DRIVER_DEVICE_ADD MouFilter_EvtDeviceAdd;
EVT_WDF_IO_QUEUE_IO_INTERNAL_DEVICE_CONTROL MouFilter_EvtIoInternalDeviceControl;



VOID
MouFilter_DispatchPassThrough(
	_In_ WDFREQUEST Request,
	_In_ WDFIOTARGET Target
	);

BOOLEAN
MouFilter_IsrHook(
	PVOID         DeviceExtension,
	PMOUSE_INPUT_DATA       CurrentInput,
	POUTPUT_PACKET          CurrentOutput,
	UCHAR                   StatusByte,
	PUCHAR                  DataByte,
	PBOOLEAN                ContinueProcessing,
	PMOUSE_STATE            MouseState,
	PMOUSE_RESET_SUBSTATE   ResetSubState
	);

VOID
MouFilter_ServiceCallback(
	IN PDEVICE_OBJECT DeviceObject,
	IN PMOUSE_INPUT_DATA InputDataStart,
	IN PMOUSE_INPUT_DATA InputDataEnd,
	IN OUT PULONG InputDataConsumed
	);

#endif  // MOUFILTER_H


